# AgendaFácil — Clientes e Agenda

Clientes continua em Python/Flask; Agenda é implementada em PHP. As duas partes se integram no mesmo endereço de navegação e compartilham o banco SQLite `instance/clientes.sqlite3`. A tela Agenda busca os clientes cadastrados em Clientes.

## Windows e VS Code

Pré-requisitos: Python Launcher (`py`) e PHP 8.1+ no PATH, com a extensão `PDO_SQLite` habilitada. No terminal do VS Code, verifique:

```powershell
py --version
php -v
php -m | findstr /I "pdo_sqlite"
```

Com os requisitos disponíveis, execute na pasta do projeto:

```powershell
.\executar_agendafacil.bat
```

O arquivo `.bat` instala Flask para o usuário atual se ainda estiver faltando, inicia os servidores Python e PHP em duas janelas de terminal e abre a tela de Clientes no navegador. Mantenha as duas janelas abertas enquanto usar o sistema. A Agenda fica no link **Agenda** ou em `http://127.0.0.1:3000/agenda/`.

Se `php -v` não funcionar, instale PHP para Windows (por exemplo, o PHP incluído no XAMPP), adicione a pasta que contém `php.exe` ao PATH e reinicie o VS Code. Se `php -m` não mostrar `pdo_sqlite`, habilite `pdo_sqlite` no `php.ini` dessa instalação do PHP.

O Go Live / Live Server não substitui os servidores: ele não executa Python nem PHP. O iniciador abre os dois serviços e o Flask encaminha `/agenda/` ao servidor PHP local.

## Executar manualmente

Em um terminal, instale Flask se necessário e inicie Clientes:

```powershell
py -m pip install --user -r requirements.txt
py app.py
```

Em outro terminal, no mesmo diretório do projeto, inicie Agenda:

```powershell
php -S 127.0.0.1:8001 -t .
```

Depois abra `http://127.0.0.1:3000/`.

## Agenda

A tela permite buscar por cliente ou serviço, filtrar pela data, criar, editar e excluir agendamentos com confirmação. Cada registro associa-se a um cliente cadastrado e guarda serviço, data, horário, status e observações. O nome e o e-mail do cliente também ficam registrados no agendamento, para preservar o histórico se o cadastro do cliente for excluído.

`app.py` cria o banco e as tabelas na inicialização; `agenda/index.php` usa o mesmo arquivo SQLite. A aplicação é um protótipo local; para acesso simultâneo na internet, publicação ou uso multiusuário, seria necessário configurar hospedagem apropriada para Python e PHP e um banco adequado.
