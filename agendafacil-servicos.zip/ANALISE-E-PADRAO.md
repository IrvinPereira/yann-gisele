# AgendaFácil — desafio de consistência da interface

## INVESTIGAR → IDENTIFICAR

| Elemento | Clientes | Agenda | Serviços | Problema identificado |
|---|---|---|---|---|
| Cadastro | Botão verde “NOVO CLIENTE” | Botão azul “Adicionar” | Apenas o símbolo “+” | A mesma ação tem cores, textos e formas diferentes. |
| Exclusão | Botão vermelho “EXCLUIR” | Apenas um “X” | Ícone de lixeira | A ação pode ficar pouco clara quando é representada só por um símbolo. |
| Edição | Botão cinza “EDITAR” | Ícone | Palavra “Alterar” | A mesma ação usa representações e termos distintos. |
| Título | Alinhado à esquerda | Centralizado | Em letras maiúsculas | Alinhamento e capitalização não seguem uma hierarquia comum. |
| Campos e espaçamento | Cantos arredondados | Campos retangulares | Cores e espaçamentos diferentes | Formas e distâncias variam sem uma regra compartilhada. |

**Problema central:** embora o sistema funcione, cada tela parece pertencer a um produto diferente porque não há convenções visuais e de interação que se repitam.

**Causa identificada:** as telas adotaram decisões próprias para ações, títulos, campos, cores e espaçamento. A inconsistência está na falta de um padrão comum, não na necessidade de cada tela ter o mesmo conteúdo.

## PADRONIZAR

Antes de redesenhar, estabelecer as regras de interface que deverão ser reconhecíveis nas três telas:

- **Ação principal:** botão destacado, com texto claro que nomeie a ação, como “Novo cliente”, “Adicionar agendamento” e “Novo serviço”.
- **Editar e excluir:** usar os mesmos rótulos — “Editar” e “Excluir” — e não depender exclusivamente de ícones. A exclusão deve pedir confirmação.
- **Títulos:** manter alinhamento à esquerda, capitalização normal e hierarquia tipográfica consistente.
- **Campos:** padronizar cantos, altura, bordas, espaçamento e indicação de campos obrigatórios.
- **Cores:** reservar a cor de destaque para a ação principal, usar cores neutras para ações secundárias e vermelho para ações destrutivas.
- **Espaçamento e estados:** definir intervalos consistentes e o mesmo tratamento para foco, interação e listas vazias.

Essas regras determinam a aparência e o comportamento esperados, independentemente da forma como cada tela venha a ser construída.

## COMPONENTIZAR

Organizar as regras em elementos de interface que possam ser identificados e repetidos: botões de ação, campos de formulário, cabeçalhos, listas, mensagens de estado vazio e confirmações. Cada elemento deve preservar a mesma aparência, nomenclatura e comportamento nas telas de Clientes, Agenda e Serviços.

## REDESENHAR

Somente depois de investigar as diferenças e definir o padrão, redesenhar as telas para que cada uma mantenha suas funções, mas apresente ações, títulos, campos, cores e espaçamentos coerentes com as mesmas regras.

## TESTAR

Conferir as três telas lado a lado: verificar se ações equivalentes têm rótulos e aparência coerentes; se títulos e campos seguem a mesma hierarquia; se exclusões pedem confirmação; e se os controles permanecem claros e utilizáveis em diferentes tamanhos de tela.

## MELHORAR

Observar as telas em uso, recolher comentários e corrigir os pontos que ainda causarem dúvida ou inconsistência. Quando uma regra mudar, atualizar o padrão e aplicá-la de forma coerente às três telas.

## Resultado esperado

Clientes, Agenda e Serviços continuam atendendo às suas próprias necessidades, mas passam a parecer partes do mesmo sistema. O redesenho vem depois da investigação, da identificação dos problemas e da definição do padrão — não antes.