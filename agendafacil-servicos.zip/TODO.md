# Progresso da atividade

- [x] Investigar e identificar as diferenças entre Clientes, Agenda e Serviços; estabelecer e documentar um padrão visual antes do redesenho.
- [x] Manter Clientes em Python/Flask e integrar a nova rota Agenda, implementada em PHP, à navegação do sistema.
- [x] Compartilhar o banco SQLite entre as telas e permitir criar, buscar, editar e excluir agendamentos associados a clientes cadastrados.
- [x] Documentar inicialização dos dois serviços no Windows com o script `executar_agendafacil.bat`.
- [ ] Implementar futuramente Serviços com as mesmas convenções visuais; permanece fora desta entrega.
