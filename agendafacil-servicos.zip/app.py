from __future__ import annotations

import os
import re
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import date
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from flask import Flask, Response, abort, redirect, render_template, request, send_from_directory, url_for

app = Flask(__name__)
DATABASE = Path(os.environ.get("AGENDA_DB_PATH", Path(app.instance_path) / "clientes.sqlite3"))
PHP_BACKEND_URL = os.environ.get("AGENDA_PHP_URL", "http://127.0.0.1:8001")
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
CLIENTES_INICIAIS = [
    ("Ana Souza", "ana.souza@email.com", "(11) 98842-1730", "2026-09-18"),
    ("Bruno Lima", "bruno.lima@email.com", "(21) 99714-2086", "2026-09-12"),
    ("Carla Mendes", "carla.mendes@email.com", "(31) 98403-7751", "2026-09-03"),
    ("Diego Martins", "diego.martins@email.com", "(41) 99162-4308", "2026-08-28"),
    ("Elaine Rocha", "elaine.rocha@email.com", "(51) 99213-8654", "2026-08-21"),
]


@contextmanager
def conectar_banco() -> Iterator[sqlite3.Connection]:
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    conexao = sqlite3.connect(DATABASE)
    conexao.row_factory = sqlite3.Row
    conexao.execute("PRAGMA foreign_keys = ON")
    try:
        yield conexao
        conexao.commit()
    except Exception:
        conexao.rollback()
        raise
    finally:
        conexao.close()


def inicializar_banco() -> None:
    with conectar_banco() as banco:
        banco.execute(
            """
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL COLLATE NOCASE UNIQUE,
                telefone TEXT NOT NULL DEFAULT '',
                criado_em TEXT NOT NULL
            )
            """
        )
        total = banco.execute("SELECT COUNT(*) FROM clientes").fetchone()[0]
        if total == 0:
            banco.executemany(
                "INSERT INTO clientes (nome, email, telefone, criado_em) VALUES (?, ?, ?, ?)",
                CLIENTES_INICIAIS,
            )
        banco.execute(
            """
            CREATE TABLE IF NOT EXISTS agendamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER,
                cliente_nome TEXT NOT NULL,
                cliente_email TEXT NOT NULL,
                servico TEXT NOT NULL,
                data TEXT NOT NULL,
                hora TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Agendado',
                observacoes TEXT NOT NULL DEFAULT '',
                criado_em TEXT NOT NULL,
                FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
            )
            """
        )


def iniciais(nome: str) -> str:
    return "".join(parte[0] for parte in nome.split()[:2]).upper()


def data_brasileira(valor: str) -> str:
    try:
        return date.fromisoformat(valor).strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return "—"


app.jinja_env.filters["date_br"] = data_brasileira


def buscar_clientes(termo: str = "") -> list[dict]:
    with conectar_banco() as banco:
        if termo:
            padrao = f"%{termo}%"
            registros = banco.execute(
                """
                SELECT id, nome, email, telefone, criado_em
                FROM clientes
                WHERE nome LIKE ? OR email LIKE ? OR telefone LIKE ?
                ORDER BY nome COLLATE NOCASE
                """,
                (padrao, padrao, padrao),
            ).fetchall()
        else:
            registros = banco.execute(
                "SELECT id, nome, email, telefone, criado_em FROM clientes ORDER BY nome COLLATE NOCASE"
            ).fetchall()
    return [
        {
            "id": registro["id"],
            "name": registro["nome"],
            "email": registro["email"],
            "phone": registro["telefone"],
            "created_at": registro["criado_em"],
            "initials": iniciais(registro["nome"]),
        }
        for registro in registros
    ]


def buscar_cliente(cliente_id: int) -> dict | None:
    with conectar_banco() as banco:
        registro = banco.execute(
            "SELECT id, nome, email, telefone, criado_em FROM clientes WHERE id = ?",
            (cliente_id,),
        ).fetchone()
    if registro is None:
        return None
    return {
        "id": registro["id"],
        "name": registro["nome"],
        "email": registro["email"],
        "phone": registro["telefone"],
        "created_at": registro["criado_em"],
    }


def renderizar_pagina(
    *,
    busca: str = "",
    form_mode: str | None = None,
    form_cliente: dict | None = None,
    erro: str = "",
    confirmar: dict | None = None,
    status: int = 200,
):
    return (
        render_template(
            "index.html",
            busca=busca,
            clientes=buscar_clientes(busca),
            form_mode=form_mode,
            form_cliente=form_cliente or {},
            erro=erro,
            confirmar=confirmar,
        ),
        status,
    )


@app.get("/manus-routes.json")
def manifesto_rotas():
    return send_from_directory(app.root_path, "manus-routes.json", mimetype="application/json")


@app.get("/servicos/")
def servicos():
    return render_template("services.html")


@app.route("/agenda", defaults={"agenda_path": ""}, methods=["GET", "POST"])
@app.route("/agenda/", defaults={"agenda_path": ""}, methods=["GET", "POST"])
@app.route("/agenda/<path:agenda_path>", methods=["GET", "POST"])
def encaminhar_agenda(agenda_path: str):
    destino = f"{PHP_BACKEND_URL.rstrip('/')}/agenda/{agenda_path}"
    if request.query_string:
        destino += "?" + request.query_string.decode("latin-1")
    cabecalhos = {}
    if request.content_type:
        cabecalhos["Content-Type"] = request.content_type
    corpo = request.get_data() if request.method != "GET" else None
    chamada = Request(destino, data=corpo, headers=cabecalhos, method=request.method)
    try:
        with urlopen(chamada, timeout=10) as resposta:
            conteudo = resposta.read()
            status = resposta.status
            cabecalhos_resposta = resposta.headers
    except HTTPError as erro_http:
        conteudo = erro_http.read()
        status = erro_http.code
        cabecalhos_resposta = erro_http.headers
    except URLError:
        return Response(
            "A tela Agenda em PHP não está iniciada. Execute executar_agendafacil.bat para abrir os dois serviços.",
            status=503,
            content_type="text/plain; charset=utf-8",
        )
    resposta_headers = {
        nome: cabecalhos_resposta[nome]
        for nome in ("Content-Type", "Location", "Cache-Control")
        if cabecalhos_resposta.get(nome)
    }
    return Response(conteudo, status=status, headers=resposta_headers)


@app.get("/")
def index():
    busca = request.args.get("q", "").strip()[:120]
    modo = request.args.get("form", "")
    if modo not in {"novo", "editar"}:
        modo = ""

    cliente_form = {}
    if modo == "editar":
        try:
            cliente_id = int(request.args.get("id", ""))
        except ValueError:
            abort(404)
        cliente_form = buscar_cliente(cliente_id)
        if cliente_form is None:
            abort(404)

    confirmar = None
    if request.args.get("confirmar"):
        try:
            cliente_id = int(request.args["confirmar"])
        except ValueError:
            abort(404)
        confirmar = buscar_cliente(cliente_id)
        if confirmar is None:
            abort(404)

    return renderizar_pagina(
        busca=busca,
        form_mode=modo or None,
        form_cliente=cliente_form,
        confirmar=confirmar,
    )


@app.post("/clientes/salvar")
def salvar_cliente():
    nome = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()
    telefone = request.form.get("phone", "").strip()
    cliente_id_raw = request.form.get("cliente_id", "").strip()

    cliente_id = None
    if cliente_id_raw:
        try:
            cliente_id = int(cliente_id_raw)
        except ValueError:
            abort(400)
        if buscar_cliente(cliente_id) is None:
            abort(404)

    modo = "editar" if cliente_id is not None else "novo"
    form_cliente = {"id": cliente_id or "", "name": nome, "email": email, "phone": telefone}

    if len(nome) < 2 or len(nome) > 80:
        return renderizar_pagina(form_mode=modo, form_cliente=form_cliente, erro="Informe um nome entre 2 e 80 caracteres.", status=400)
    if len(email) > 120 or not EMAIL_RE.fullmatch(email):
        return renderizar_pagina(form_mode=modo, form_cliente=form_cliente, erro="Informe um e-mail válido.", status=400)
    if len(telefone) > 24:
        return renderizar_pagina(form_mode=modo, form_cliente=form_cliente, erro="O telefone deve ter até 24 caracteres.", status=400)

    with conectar_banco() as banco:
        existente = banco.execute(
            "SELECT id FROM clientes WHERE email = ? COLLATE NOCASE AND (? IS NULL OR id != ?)",
            (email, cliente_id, cliente_id),
        ).fetchone()
        if existente:
            return renderizar_pagina(form_mode=modo, form_cliente=form_cliente, erro="Este e-mail já está cadastrado.", status=400)

        if cliente_id is None:
            banco.execute(
                "INSERT INTO clientes (nome, email, telefone, criado_em) VALUES (?, ?, ?, ?)",
                (nome, email, telefone, date.today().isoformat()),
            )
        else:
            banco.execute(
                "UPDATE clientes SET nome = ?, email = ?, telefone = ? WHERE id = ?",
                (nome, email, telefone, cliente_id),
            )

    return redirect(url_for("index"), code=303)


@app.post("/clientes/<int:cliente_id>/excluir")
def excluir_cliente(cliente_id: int):
    with conectar_banco() as banco:
        banco.execute("DELETE FROM clientes WHERE id = ?", (cliente_id,))
    return redirect(url_for("index"), code=303)


inicializar_banco()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "3000")), debug=False)
