<?php
declare(strict_types=1);

const APP_BASE = '/agenda/';
const STATUSES = ['Agendado', 'Concluído', 'Cancelado'];

function e(string|int|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function textSlice(string $value, int $limit): string
{
    $matches = preg_match_all('/./us', $value, $characters);
    return $matches === false ? substr($value, 0, $limit) : implode('', array_slice($characters[0], 0, $limit));
}

function textLength(string $value): int
{
    $matches = preg_match_all('/./us', $value);
    return $matches === false ? strlen($value) : $matches;
}

function initials(string $name): string
{
    $parts = array_slice(preg_split('/\s+/', trim($name)) ?: [], 0, 2);
    return implode('', array_map(static fn(string $part): string => textSlice($part, 1), $parts));
}

function goToAgenda(): never
{
    header('Location: ' . APP_BASE, true, 303);
    exit;
}

function validDate(string $value): bool
{
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return false;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value;
}

$dbPath = getenv('AGENDA_DB_PATH') ?: dirname(__DIR__) . DIRECTORY_SEPARATOR . 'instance' . DIRECTORY_SEPARATOR . 'clientes.sqlite3';
if (!extension_loaded('pdo_sqlite')) {
    http_response_code(500);
    exit('O PHP precisa da extensão PDO_SQLite habilitada para compartilhar o banco de Clientes.');
}
if (!is_file($dbPath)) {
    http_response_code(503);
    exit('Banco de Clientes não encontrado. Inicie primeiro a aplicação Python pelo executar_agendafacil.bat.');
}

try {
    $db = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $db->exec('PRAGMA foreign_keys = ON');
    $db->exec('PRAGMA busy_timeout = 5000');
    $hasClientsTable = $db->query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'clientes'")->fetchColumn();
    if (!$hasClientsTable) {
        http_response_code(503);
        exit('A tabela de Clientes ainda não foi criada. Inicie primeiro a aplicação Python.');
    }
    $db->exec(
        "CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            cliente_nome TEXT NOT NULL,
            cliente_email TEXT NOT NULL,
            servico TEXT NOT NULL,
            data TEXT NOT NULL,
            hora TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Agendado',
            observacoes TEXT NOT NULL DEFAULT '',
            criado_em TEXT NOT NULL,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
        )"
    );
} catch (Throwable $error) {
    http_response_code(500);
    exit('Não foi possível abrir o banco compartilhado. Confira se a tela de Clientes está configurada corretamente.');
}

$clients = $db->query('SELECT id, nome, email FROM clientes ORDER BY nome COLLATE NOCASE')->fetchAll();
$search = trim(textSlice((string) ($_GET['q'] ?? ''), 120));
$dateFilter = (string) ($_GET['data'] ?? '');
if ($dateFilter !== '' && !validDate($dateFilter)) {
    $dateFilter = '';
}

$formMode = '';
$formData = ['id' => '', 'cliente_id' => '', 'servico' => '', 'data' => '', 'hora' => '', 'status' => 'Agendado', 'observacoes' => ''];
$errorMessage = '';
$confirmAppointment = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['acao'] ?? '');
    if ($action === 'excluir') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        if ($id) {
            $delete = $db->prepare('DELETE FROM agendamentos WHERE id = ?');
            $delete->execute([$id]);
        }
        goToAgenda();
    }

    if ($action === 'salvar') {
        $idValue = trim((string) ($_POST['id'] ?? ''));
        $id = $idValue === '' ? null : filter_var($idValue, FILTER_VALIDATE_INT);
        $clientId = filter_var($_POST['cliente_id'] ?? null, FILTER_VALIDATE_INT);
        $service = trim((string) ($_POST['servico'] ?? ''));
        $appointmentDate = trim((string) ($_POST['data'] ?? ''));
        $appointmentTime = trim((string) ($_POST['hora'] ?? ''));
        $status = (string) ($_POST['status'] ?? 'Agendado');
        $notes = trim((string) ($_POST['observacoes'] ?? ''));
        $formMode = $id ? 'editar' : 'novo';
        $formData = [
            'id' => $id ?: '',
            'cliente_id' => $clientId ?: '',
            'servico' => $service,
            'data' => $appointmentDate,
            'hora' => $appointmentTime,
            'status' => $status,
            'observacoes' => $notes,
        ];

        $clientQuery = $db->prepare('SELECT id, nome, email FROM clientes WHERE id = ?');
        $clientQuery->execute([$clientId]);
        $client = $clientQuery->fetch();

        if (!$client) {
            $errorMessage = 'Selecione um cliente cadastrado.';
        } elseif (textLength($service) < 2 || textLength($service) > 100) {
            $errorMessage = 'Informe um serviço entre 2 e 100 caracteres.';
        } elseif (!validDate($appointmentDate)) {
            $errorMessage = 'Informe uma data válida.';
        } elseif (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $appointmentTime)) {
            $errorMessage = 'Informe um horário válido.';
        } elseif (!in_array($status, STATUSES, true)) {
            $errorMessage = 'Selecione um status válido.';
        } elseif (textLength($notes) > 500) {
            $errorMessage = 'As observações devem ter até 500 caracteres.';
        } else {
            if ($id) {
                $update = $db->prepare(
                    'UPDATE agendamentos SET cliente_id = ?, cliente_nome = ?, cliente_email = ?, servico = ?, data = ?, hora = ?, status = ?, observacoes = ? WHERE id = ?'
                );
                $update->execute([$client['id'], $client['nome'], $client['email'], $service, $appointmentDate, $appointmentTime, $status, $notes, $id]);
            } else {
                $insert = $db->prepare(
                    'INSERT INTO agendamentos (cliente_id, cliente_nome, cliente_email, servico, data, hora, status, observacoes, criado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $insert->execute([$client['id'], $client['nome'], $client['email'], $service, $appointmentDate, $appointmentTime, $status, $notes, date('Y-m-d')]);
            }
            goToAgenda();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (($_GET['form'] ?? '') === 'novo') {
        $formMode = 'novo';
        $formData['data'] = date('Y-m-d');
        $formData['hora'] = date('H:00');
    } elseif (($_GET['form'] ?? '') === 'editar') {
        $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
        $edit = $id ? $db->prepare('SELECT * FROM agendamentos WHERE id = ?') : null;
        if (!$edit) {
            http_response_code(404);
            exit('Agendamento não encontrado.');
        }
        $edit->execute([$id]);
        $record = $edit->fetch();
        if (!$record) {
            http_response_code(404);
            exit('Agendamento não encontrado.');
        }
        $formMode = 'editar';
        $formData = [
            'id' => $record['id'],
            'cliente_id' => $record['cliente_id'] ?? '',
            'servico' => $record['servico'],
            'data' => $record['data'],
            'hora' => $record['hora'],
            'status' => $record['status'],
            'observacoes' => $record['observacoes'],
        ];
    }

    $confirmId = filter_var($_GET['confirmar'] ?? null, FILTER_VALIDATE_INT);
    if ($confirmId) {
        $confirmQuery = $db->prepare('SELECT id, cliente_nome, servico, data, hora FROM agendamentos WHERE id = ?');
        $confirmQuery->execute([$confirmId]);
        $confirmAppointment = $confirmQuery->fetch() ?: null;
    }
}

$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(a.cliente_nome LIKE ? OR a.cliente_email LIKE ? OR a.servico LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if ($dateFilter !== '') {
    $where[] = 'a.data = ?';
    $params[] = $dateFilter;
}
$sql = "SELECT a.*, COALESCE(c.nome, a.cliente_nome) AS nome_exibido, COALESCE(c.email, a.cliente_email) AS email_exibido
        FROM agendamentos a LEFT JOIN clientes c ON c.id = a.cliente_id";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY a.data ASC, a.hora ASC, a.id ASC';
$listQuery = $db->prepare($sql);
$listQuery->execute($params);
$appointments = $listQuery->fetchAll();

function displayDate(string $isoDate): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $isoDate);
    return $date ? $date->format('d/m/Y') : '—';
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#ffffff">
  <title>Agenda — AgendaFácil</title>
  <link rel="stylesheet" href="/static/styles.css">
</head>
<body>
  <header class="topbar">
    <div class="topbar-inner">
      <a class="brand" href="/" aria-label="AgendaFácil — Clientes">
        <span class="brand-mark" aria-hidden="true">a.</span>
        <span>AgendaFácil</span>
      </a>
      <nav class="main-nav" aria-label="Navegação principal">
        <a class="nav-link" href="/">Clientes</a>
        <a class="nav-link active" href="/agenda/" aria-current="page">Agenda</a>
        <a class="nav-link" href="/servicos/">Serviços</a>
      </nav>
    </div>
  </header>

  <main class="page-shell">
    <section class="page-heading">
      <div>
        <p class="eyebrow">ATENDIMENTOS</p>
        <h1>Agenda</h1>
        <p class="description">Organize os próximos horários e atendimentos.</p>
      </div>
      <a class="button button-primary" href="/agenda/?form=novo">＋ <span>Novo agendamento</span></a>
    </section>

    <section class="panel" aria-label="Lista de agendamentos">
      <div class="toolbar agenda-toolbar">
        <form class="search agenda-search" method="get" action="/agenda/" role="search">
          <label class="sr-only" for="q">Buscar agendamento</label>
          <span aria-hidden="true" class="search-icon">⌕</span>
          <input id="q" name="q" type="search" value="<?= e($search) ?>" placeholder="Buscar cliente ou serviço">
          <?php if ($dateFilter !== ''): ?><input type="hidden" name="data" value="<?= e($dateFilter) ?>"><?php endif; ?>
          <?php if ($search !== ''): ?><a class="clear-search" href="/agenda/" aria-label="Limpar busca">×</a><?php endif; ?>
        </form>
        <form class="date-filter" method="get" action="/agenda/">
          <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
          <label class="sr-only" for="filter-date">Filtrar por data</label>
          <input id="filter-date" type="date" name="data" value="<?= e($dateFilter) ?>" aria-label="Filtrar por data">
          <?php if ($dateFilter !== ''): ?><a class="filter-reset" href="/agenda/" aria-label="Limpar filtro de data">×</a><?php endif; ?>
        </form>
        <span class="count"><?= count($appointments) ?> <?= count($appointments) === 1 ? 'agendamento' : 'agendamentos' ?></span>
      </div>

      <?php if ($appointments): ?>
      <div class="table-wrap">
        <table class="agenda-table">
          <thead><tr>
            <th scope="col">Cliente</th>
            <th scope="col">Serviço</th>
            <th scope="col">Data e horário</th>
            <th scope="col">Status</th>
            <th scope="col" class="actions-heading">Ações</th>
          </tr></thead>
          <tbody>
          <?php foreach ($appointments as $appointment): ?>
            <?php $statusClass = match ($appointment['status']) { 'Concluído' => 'status-done', 'Cancelado' => 'status-cancelled', default => 'status-scheduled' }; ?>
            <tr>
              <td><div class="person">
                <span class="avatar" aria-hidden="true"><?= e(initials($appointment['nome_exibido'])) ?></span>
                <span class="person-copy"><span class="person-name"><?= e($appointment['nome_exibido']) ?></span><span class="person-email"><?= e($appointment['email_exibido']) ?></span></span>
              </div></td>
              <td><?= e($appointment['servico']) ?></td>
              <td class="date-cell"><span class="appointment-date"><?= e(displayDate($appointment['data'])) ?></span><span class="appointment-time"><?= e($appointment['hora']) ?></span></td>
              <td><span class="status-pill <?= e($statusClass) ?>"><?= e($appointment['status']) ?></span></td>
              <td><div class="row-actions">
                <a class="action-button" href="/agenda/?form=editar&amp;id=<?= e($appointment['id']) ?>">Editar</a>
                <a class="action-button delete" href="/agenda/?confirmar=<?= e($appointment['id']) ?>">Excluir</a>
              </div></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php else: ?>
      <div class="empty-state"><span class="empty-mark" aria-hidden="true">○</span>
        <h2><?= $search !== '' || $dateFilter !== '' ? 'Nenhum agendamento encontrado' : 'Sua agenda está vazia' ?></h2>
        <p><?= $search !== '' || $dateFilter !== '' ? 'Experimente mudar os filtros.' : 'Adicione um agendamento para começar.' ?></p>
      </div>
      <?php endif; ?>
      <div class="panel-footer"></div>
    </section>
    <p class="storage-note">Os agendamentos usam o mesmo banco local da tela de Clientes.</p>
  </main>

  <?php if ($formMode !== ''): ?>
  <div class="overlay"><section class="dialog agenda-dialog" role="dialog" aria-modal="true" aria-labelledby="form-title">
    <div class="dialog-heading"><div><p class="eyebrow">AGENDA</p><h2 id="form-title"><?= $formMode === 'editar' ? 'Editar agendamento' : 'Novo agendamento' ?></h2></div><a class="close-link" href="/agenda/" aria-label="Fechar">×</a></div>
    <?php if ($errorMessage !== ''): ?><p class="error-message" role="alert"><?= e($errorMessage) ?></p><?php endif; ?>
    <form action="/agenda/" method="post">
      <input type="hidden" name="acao" value="salvar"><input type="hidden" name="id" value="<?= e($formData['id']) ?>">
      <label class="field-label" for="client-id">Cliente <span>*</span></label>
      <select class="text-field" id="client-id" name="cliente_id" required>
        <option value="">Selecione um cliente</option>
        <?php foreach ($clients as $client): ?>
          <option value="<?= e($client['id']) ?>" <?= (string) $formData['cliente_id'] === (string) $client['id'] ? 'selected' : '' ?>><?= e($client['nome']) ?> — <?= e($client['email']) ?></option>
        <?php endforeach; ?>
      </select>
      <label class="field-label" for="service">Serviço <span>*</span></label>
      <input class="text-field" id="service" name="servico" value="<?= e($formData['servico']) ?>" placeholder="Ex.: Consulta inicial" maxlength="100" required>
      <div class="field-grid">
        <div><label class="field-label" for="date">Data <span>*</span></label><input class="text-field" id="date" type="date" name="data" value="<?= e($formData['data']) ?>" required></div>
        <div><label class="field-label" for="time">Horário <span>*</span></label><input class="text-field" id="time" type="time" name="hora" value="<?= e($formData['hora']) ?>" required></div>
      </div>
      <label class="field-label" for="status">Status</label>
      <select class="text-field" id="status" name="status">
        <?php foreach (STATUSES as $statusOption): ?><option value="<?= e($statusOption) ?>" <?= $formData['status'] === $statusOption ? 'selected' : '' ?>><?= e($statusOption) ?></option><?php endforeach; ?>
      </select>
      <label class="field-label" for="notes">Observações <small>Opcional</small></label>
      <textarea class="text-field text-area" id="notes" name="observacoes" maxlength="500" placeholder="Detalhes para este atendimento"><?= e($formData['observacoes']) ?></textarea>
      <div class="dialog-actions"><a class="button button-secondary" href="/agenda/">Cancelar</a><button class="button button-primary" type="submit"><?= $formMode === 'editar' ? 'Salvar alterações' : 'Salvar agendamento' ?></button></div>
    </form>
  </section></div>
  <?php endif; ?>

  <?php if ($confirmAppointment): ?>
  <div class="overlay"><section class="dialog confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
    <div class="dialog-heading"><div><p class="eyebrow">CONFIRMAÇÃO</p><h2 id="confirm-title">Excluir agendamento?</h2></div><a class="close-link" href="/agenda/" aria-label="Cancelar">×</a></div>
    <p class="confirm-copy">O atendimento de <strong><?= e($confirmAppointment['cliente_nome']) ?></strong> para <strong><?= e($confirmAppointment['servico']) ?></strong> em <?= e(displayDate($confirmAppointment['data'])) ?> às <?= e($confirmAppointment['hora']) ?> será removido.</p>
    <div class="dialog-actions"><a class="button button-secondary" href="/agenda/">Cancelar</a><form action="/agenda/" method="post"><input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="<?= e($confirmAppointment['id']) ?>"><button class="button button-danger" type="submit">Excluir agendamento</button></form></div>
  </section></div>
  <?php endif; ?>
</body>
</html>
