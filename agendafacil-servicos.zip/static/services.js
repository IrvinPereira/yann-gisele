const storageKey = 'agendafacil-servicos';
const initialServices = [
  { id: 1, name: 'Corte feminino', description: 'Corte, lavagem e finalização.', duration: '1 hora', price: 85 },
  { id: 2, name: 'Barba', description: 'Modelagem e acabamento da barba.', duration: '30 min', price: 45 },
  { id: 3, name: 'Coloração', description: 'Aplicação de cor e tratamento.', duration: '2 horas', price: 180 },
  { id: 4, name: 'Manicure', description: 'Cuidado completo das unhas.', duration: '45 min', price: 55 }
];

const list = document.querySelector('#service-list');
const count = document.querySelector('#service-count');
const searchInput = document.querySelector('#search-input');
const clearSearch = document.querySelector('[data-action="clear-search"]');
const serviceModal = document.querySelector('#service-modal');
const confirmModal = document.querySelector('#confirm-modal');
const form = document.querySelector('#service-form');
const error = document.querySelector('#service-error');
let pendingDelete = null;

function getServices() {
  const saved = localStorage.getItem(storageKey);
  if (!saved) {
    localStorage.setItem(storageKey, JSON.stringify(initialServices));
    return [...initialServices];
  }
  try {
    return JSON.parse(saved);
  } catch {
    return [...initialServices];
  }
}

function saveServices(services) {
  localStorage.setItem(storageKey, JSON.stringify(services));
}

function formatPrice(value) {
  return Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function render() {
  const services = getServices();
  const query = searchInput.value.trim().toLocaleLowerCase('pt-BR');
  const visible = services.filter((service) => `${service.name} ${service.description}`.toLocaleLowerCase('pt-BR').includes(query));
  count.textContent = `${visible.length} ${visible.length === 1 ? 'serviço' : 'serviços'}`;
  clearSearch.hidden = !query;

  if (!visible.length) {
    list.innerHTML = `<div class="empty-state"><span class="empty-mark" aria-hidden="true">○</span><h2>${query ? 'Nenhum serviço encontrado' : 'Sua lista está vazia'}</h2><p>${query ? 'Experimente mudar sua busca.' : 'Adicione seu primeiro serviço para começar.'}</p></div>`;
    return;
  }

  list.innerHTML = `<div class="service-grid">${visible.map((service) => `
    <article class="service-card">
      <div class="service-card-top">
        <span class="service-icon" aria-hidden="true">✦</span>
        <div class="service-copy"><h2>${escapeHtml(service.name)}</h2><p>${escapeHtml(service.description || 'Sem descrição')}</p></div>
      </div>
      <div class="service-meta"><span>${escapeHtml(service.duration)}</span><strong>${formatPrice(service.price)}</strong></div>
      <div class="service-actions"><button class="action-button" type="button" data-action="edit" data-id="${service.id}">Editar</button><button class="action-button delete" type="button" data-action="ask-delete" data-id="${service.id}">Excluir</button></div>
    </article>`).join('')}</div>`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character]));
}

function openForm(service = null) {
  form.reset();
  error.hidden = true;
  document.querySelector('#service-id').value = service?.id || '';
  document.querySelector('#service-name').value = service?.name || '';
  document.querySelector('#service-description').value = service?.description || '';
  document.querySelector('#service-duration').value = service?.duration || '30 min';
  document.querySelector('#service-price').value = service ? Number(service.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) : '';
  document.querySelector('#service-form-title').textContent = service ? 'Editar serviço' : 'Novo serviço';
  serviceModal.hidden = false;
  document.querySelector('#service-name').focus();
}

function closeForm() {
  serviceModal.hidden = true;
}

function askDelete(id) {
  const service = getServices().find((item) => item.id === id);
  if (!service) return;
  pendingDelete = id;
  document.querySelector('#confirm-name').textContent = service.name;
  confirmModal.hidden = false;
}

function closeDelete() {
  pendingDelete = null;
  confirmModal.hidden = true;
}

document.addEventListener('click', (event) => {
  const trigger = event.target.closest('[data-action]');
  if (!trigger) return;
  const action = trigger.dataset.action;
  if (action === 'new') openForm();
  if (action === 'close') closeForm();
  if (action === 'clear-search') { searchInput.value = ''; render(); searchInput.focus(); }
  if (action === 'edit') openForm(getServices().find((service) => service.id === Number(trigger.dataset.id)));
  if (action === 'ask-delete') askDelete(Number(trigger.dataset.id));
  if (action === 'cancel-delete') closeDelete();
  if (action === 'delete' && pendingDelete) {
    saveServices(getServices().filter((service) => service.id !== pendingDelete));
    closeDelete();
    render();
  }
});

searchInput.addEventListener('input', render);

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const name = document.querySelector('#service-name').value.trim();
  const description = document.querySelector('#service-description').value.trim();
  const duration = document.querySelector('#service-duration').value;
  const priceText = document.querySelector('#service-price').value.trim().replace(/\./g, '').replace(',', '.').replace(/[^\d.]/g, '');
  const price = Number(priceText);
  if (name.length < 2) { error.textContent = 'Informe um nome entre 2 e 80 caracteres.'; error.hidden = false; return; }
  if (!price || price < 0) { error.textContent = 'Informe um preço válido.'; error.hidden = false; return; }

  const services = getServices();
  const id = Number(document.querySelector('#service-id').value);
  const service = { id: id || Date.now(), name, description, duration, price };
  const updated = id ? services.map((item) => item.id === id ? service : item) : [...services, service];
  saveServices(updated);
  closeForm();
  render();
});

render();
