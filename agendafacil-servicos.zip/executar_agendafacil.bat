@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>&1
if errorlevel 1 goto erro_python

where php >nul 2>&1
if errorlevel 1 goto erro_php

php -m | findstr /I "pdo_sqlite" >nul
if errorlevel 1 goto erro_sqlite

py -c "import flask" >nul 2>&1
if not errorlevel 1 goto iniciar

echo Instalando Flask para o usuario atual...
py -m pip install --user -r requirements.txt
if errorlevel 1 goto erro_flask

:iniciar
echo Abrindo Clientes (Python) e Agenda (PHP)...
start "AgendaFacil - Clientes Python" /D "%CD%" py app.py
timeout /t 3 /nobreak >nul
start "AgendaFacil - Agenda PHP" /D "%CD%" php -S 127.0.0.1:8001 -t .
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:3000/"
echo.
echo Clientes: http://127.0.0.1:3000/
echo Agenda:   http://127.0.0.1:3000/agenda/
echo Mantenha abertas as duas janelas dos servidores enquanto usar o sistema.
goto fim

:erro_python
echo Python Launcher nao encontrado. Instale Python e o comando py.
goto erro

:erro_php
echo PHP CLI nao encontrado. Instale PHP e adicione a pasta do php.exe ao PATH.
echo Verifique no terminal com: php -v
goto erro

:erro_sqlite
echo A extensao PDO_SQLite nao esta habilitada no PHP.
echo Ative pdo_sqlite no php.ini e confira com: php -m ^| findstr /I pdo_sqlite
goto erro

:erro_flask
echo Nao foi possivel instalar Flask automaticamente.
echo Tente: py -m pip install --user -r requirements.txt
goto erro

:erro
echo.
pause
exit /b 1

:fim
endlocal
